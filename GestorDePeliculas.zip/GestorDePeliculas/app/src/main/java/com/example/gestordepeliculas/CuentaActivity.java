package com.example.gestordepeliculas;

import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class CuentaActivity extends AppCompatActivity {

    TextView recomendacionTV;
    String url;
    TextView welcome;
    ImageView imagenFondo;
    static int ID_USUARIO_ACTUAL;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cuenta);

        recomendacionTV = (TextView) findViewById(R.id.recomendacionTV);
        url = "https://www.culturagenial.com/es/peliculas-interesantes/";
        welcome = (TextView) findViewById(R.id.welcome);
        imagenFondo = (ImageView) findViewById(R.id.imagenFondo);


        ID_USUARIO_ACTUAL =  cargarPerfil();

        //Si tocamos el TV nos redirecciona a la direccion asignada en url
        recomendacionTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }
    public void photoViewer(View v){
        if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size() != 0){
            startActivity(new Intent(CuentaActivity.this, VisorDeFotos.class));
        }else{
            Toast.makeText(this,R.string.noFilmsAdded,Toast.LENGTH_LONG).show();
        }

    }
    public void accederEstadisticas(View v){
        if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size() != 0){
            Intent stats = new Intent(CuentaActivity.this,estadisticas.class);
            startActivity(stats);
        }else{
            Toast.makeText(this,R.string.noFilmsAdded,Toast.LENGTH_LONG).show();
        }
    }
    public void accederBiblioteca(View v){
        if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size() != 0){
            startActivity(new Intent(CuentaActivity.this, miBiblioteca.class));
        }else{
            Toast.makeText(this,R.string.noFilmsAdded,Toast.LENGTH_LONG).show();
        }
    }
    public void updateFilms(View v){
        if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size() != 0){
            startActivity(new Intent(CuentaActivity.this, ActualizarVistas.class));
        }else{
            Toast.makeText(this,R.string.noFilmsAdded,Toast.LENGTH_LONG).show();
        }
    }
    public void lanzarAyuda(View v){
        ayudaCuenta ayuda = new ayudaCuenta();
        FragmentManager fm = this.getSupportFragmentManager();
        ayuda.setCancelable(false);
        ayuda.show(fm,"ayuda");
    }
    public void noteFilm (View v){
        startActivity(new Intent (CuentaActivity.this, PopUpAnotadorPeliculas.class));
    }
    //Carga los datos del usuario que ha iniciado la sesión
    private int cargarPerfil (){
        for (int i = 0; i < MainActivity.users.size(); i++){
            if(MainActivity.idLogeado == MainActivity.users.get(i).ID_USUARIO){
                if(MainActivity.users.get(i).masculino){
                    welcome.setText("Bienvenido, \n"+ MainActivity.users.get(i).NOM_USUARIO + " " + MainActivity.users.get(i).APELLIDOS_USUARIO);
                }else{
                    welcome.setText("Bienvenida, \n"+ MainActivity.users.get(i).NOM_USUARIO + " " + MainActivity.users.get(i).APELLIDOS_USUARIO);
                }
                imagenFondo.setImageDrawable(MainActivity.users.get(i).fondo);
                return i;
            }
        }
        return 0;
    }
    //Mostrar Ocultar Menu
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.cuentabar, menu);
        return true;
    }
    //Controles del menu
    public boolean onOptionsItemSelected(MenuItem item){

        int selector = item.getItemId();
        if(selector == R.id.itemAyuda){
            ayudaCuenta ayuda = new ayudaCuenta();
            FragmentManager fm = this.getSupportFragmentManager();
            ayuda.setCancelable(false);
            ayuda.show(fm,"ayuda");
        }else if(selector == R.id.itemSalir){
            cerrarSesion();
        }
        return super.onOptionsItemSelected(item);

    }
    public void onBackPressed (){
        cerrarSesion();
    }

    private void cerrarSesion(){
        //Mostramos el dialogo
        salirCuenta salir = new salirCuenta();
        FragmentManager fm = this.getSupportFragmentManager();
        salir.setCancelable(false);
        salir.show(fm,"salir");
    }
}
