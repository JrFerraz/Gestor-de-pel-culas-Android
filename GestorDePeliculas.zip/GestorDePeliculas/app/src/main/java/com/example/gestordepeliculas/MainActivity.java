package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText nameLoginET;
    EditText ContraseñaLoginET;
    public static int idLogeado = 0;
    public static ArrayList<Usuario> users = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        //Usuario por defecto que cree para facilitarme la programación del proyecto
        Usuario ejemplo = new Usuario("Jorge","Ferraz Oviedo", "1234",true,getResources().getDrawable(R.drawable.rocky));
        ejemplo.ID_USUARIO = 0;
        users.add(ejemplo);

        nameLoginET = (EditText) findViewById(R.id.nameLoginET);
        ContraseñaLoginET = (EditText) findViewById(R.id.ContraseñaLoginET);
    }
    //Intenta el login, si lo consigue pasa a la cuenta, si no sale LoginIncorrecto
    public void tryLogin(View v){
        if(ComprobarLogin()){
            Intent cuenta = new Intent(MainActivity.this, CuentaActivity.class);
            startActivity(cuenta);
        }else {
            LoginIncorrecto error = new LoginIncorrecto();
            FragmentManager fm = this.getSupportFragmentManager();
            error.show(fm,"errorLogin");
        }
    }
    //Redirecciona a Registro
    public void showDialogR(View v){
        Intent registro = new Intent(MainActivity.this, RegistroActivity.class);
        startActivity(registro);
    }
    //comprueba que el login es correcto, este boolean determina el rumbo de tryLogin
    private boolean ComprobarLogin (){
        if(nameLoginET.getText().toString().equals("") || ContraseñaLoginET.getText().toString().equals("")){
            Toast.makeText(this, R.string.nullLogin,Toast.LENGTH_LONG).show();
        }else{
            for (int i = 0; i < users.size(); i++){
                if(users.get(i).NOM_USUARIO.equals(nameLoginET.getText().toString()) && users.get(i).PASS_USUARIO.equals(ContraseñaLoginET.getText().toString())){
                    idLogeado = users.get(i).ID_USUARIO;
                    return true;
                }
            }
        }
        return false;
    }

}