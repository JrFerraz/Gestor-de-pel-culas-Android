package com.example.gestordepeliculas;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class SalirRegistro extends DialogFragment {

    //Fragment que se invoca cuando queramos salir del registro
    public Dialog onCreateDialog(Bundle savedInstance) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.Atencion).setIcon(R.drawable.darkalerticon)
                .setMessage(R.string.quieres_salir)
                .setNegativeButton(R.string.noAcept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), R.string.regNoCancelado, Toast.LENGTH_LONG).show();
                    }
                })
                .setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), R.string.regAbandonado, Toast.LENGTH_LONG).show();
                        Intent cuenta = new Intent(getContext(), MainActivity.class);
                        startActivity(cuenta);
                        getActivity().finish();
                    }
                });
        return builder.create();
    }
}
