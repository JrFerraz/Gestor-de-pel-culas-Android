package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class estadisticas extends AppCompatActivity {

    public TextView peliMasVista;
    TextView peliMejorValorada;
    TextView peliPeorValorada;
    TextView GeneroMasVisto;
    TextView GeneroMenosVisto;
    TextView numPelisVistas;
    TextView numPelisPendientes;
    int userIndex = CuentaActivity.ID_USUARIO_ACTUAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        peliMasVista = (TextView) findViewById(R.id.peliMasVista);
        peliMejorValorada = (TextView) findViewById(R.id.peliMejorValorada);
        peliPeorValorada = (TextView) findViewById(R.id.peliPeorValorada);
        GeneroMasVisto = (TextView) findViewById(R.id.GeneroMasVisto);
        GeneroMenosVisto = (TextView) findViewById(R.id.GeneroMenosVisto);
        numPelisVistas = (TextView) findViewById(R.id.numPelisVistas);
        numPelisPendientes = (TextView) findViewById(R.id.numPelisPendientes);

        aplicarEstats();
    }

    //Se aplican los calculos y se imprimen por pantalla los resultados
    @SuppressLint("SetTextI18n")
    public void  aplicarEstats(){
        System.out.println(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size());
        peliMasVista.setText(peliMasVista.getText().toString() + MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(peliMasVista()).NOMBRE_PELICULA+"");
        peliMejorValorada.setText(peliMejorValorada.getText().toString() + MainActivity.users.get(userIndex).peliMejorValorada);
        peliPeorValorada.setText(peliPeorValorada.getText().toString() + MainActivity.users.get(userIndex).peliPeorValorada);

        GeneroMasVisto.setText(GeneroMasVisto.getText().toString() + MainActivity.users.get(userIndex).generoMasVisto);
        GeneroMenosVisto.setText(GeneroMenosVisto.getText().toString() + MainActivity.users.get(userIndex).generoMenosVisto);
        numPelisVistas.setText(numPelisVistas.getText().toString() + numeroDePelisVistas());
        numPelisPendientes.setText(numPelisPendientes.getText().toString() + numeroDePelisNoVistas());

    }

    @Override
    public void onBackPressed (){
        finish();
    }

    //lleva un conteo de cuantas veces se ha visto cada peli, si la siguiente se ha visto más, ese conteo se actualiza
    public int peliMasVista(){
        int aux = 0;
        int ind = 0;
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size();i++){
            if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).numVisualizaciones > aux){
                ind = i;
                aux = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).numVisualizaciones;
            }
        }
        return ind;
    }

    //Determina cuantas pelis están marcadas como vistas
    public int numeroDePelisVistas(){
        int numVistas = 0;
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size();i++){
            if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PELICULA_VISTA){
                numVistas++;
            }
        }
        return numVistas;
    }
    //Funcion contraria a la anterior
    public int numeroDePelisNoVistas(){
        int numNoVistas = 0;
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size();i++){
            if(!MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PELICULA_VISTA){
                numNoVistas++;
            }
        }
        return numNoVistas;
    }
}