package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class VisorDeFotos extends AppCompatActivity {

    LinearLayout fotoAtual;
    ImageButton botonAnterior;
    ImageButton botonSiguiente;

    int contador = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visor_de_fotos);

        fotoAtual = (LinearLayout) findViewById(R.id.fotoAtual);
        botonAnterior = (ImageButton) findViewById(R.id.botonAnterior);
        botonSiguiente = (ImageButton) findViewById(R.id.botonSiguiente);

        fotoAtual.setBackground(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(contador).fotoPelicula);
    }
    //Carga el Background con la foto anterior
    public void antButton(View v){
        if (contador != 0){
            contador--;
            fotoAtual.setBackground(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(contador).fotoPelicula);
        }
    }
    //Carga el Background con la foto siguiente
    public void sigButton(View v){
        if (contador != MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size()-1){
            contador++;
            fotoAtual.setBackground(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(contador).fotoPelicula);
        }
    }
}