package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class miBiblioteca extends AppCompatActivity {

    LinearLayout RelativeLayoutDePeliculas;
    TextView text, tituloPelicula;
    LinearLayout contenedorDeLayoutsPeliculas;
    ImageView imgPelicula, estrellaPelicula1, estrellaPelicula2, estrellaPelicula3, estrellaPelicula4, estrellaPelicula5;
    TableLayout tablaPelicula;
    ImageButton editarPelicula;
    TableRow tablaTituloPelicula, tablaCalificacionesPelicula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_biblioteca);

        RelativeLayoutDePeliculas = (LinearLayout) findViewById(R.id.RelativeLayoutDePeliculas);
        text = (TextView) findViewById(R.id.text);
        contenedorDeLayoutsPeliculas = (LinearLayout) findViewById(R.id.contenedorDeRelativeLayouts);


        //Genero layouts de forma programática para cada película
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size(); i++){
            generarLayoutPelicula(i);
        }
    }
    //funcion aplicada para crear cada layout
    public void generarLayoutPelicula(int i){
        //Iniciar Layout Programaticamente
        View inflate = View.inflate(this,R.layout.peliculas_relative_layout,null);
        tituloPelicula = (TextView) inflate.findViewById(R.id.tituloPelicula);
        tituloPelicula.setText(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).NOMBRE_PELICULA);
        imgPelicula = (ImageView) inflate.findViewById(R.id.imgPelicula);
        imgPelicula.setImageDrawable(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).fotoPelicula);
        editarPelicula = (ImageButton) inflate.findViewById(R.id.editarPelicula);
        editarPelicula.setId(i);
        //aqui pasamos una variable como final para que cada boton tenga un indice distinto, ya que si no había un error en el que solo cogia el último indice
        final int index = i;
        editarPelicula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("TAG", "The index is" + index);
                Intent intent = new Intent(miBiblioteca.this,peliSeleccionadaActivity.class);
                intent.putExtra("IndexPeli", index);
                startActivity(intent);
            }
        });
        estrellaPelicula1 = (ImageView) inflate.findViewById(R.id.estrellaPelicula1);
        estrellaPelicula2 = (ImageView) inflate.findViewById(R.id.estrellaPelicula2);
        estrellaPelicula3 = (ImageView) inflate.findViewById(R.id.estrellaPelicula3);
        estrellaPelicula4 = (ImageView) inflate.findViewById(R.id.estrellaPelicula4);
        estrellaPelicula5 = (ImageView) inflate.findViewById(R.id.estrellaPelicula5);
        pintarPuntuacion(index);
        tablaPelicula = (TableLayout) inflate.findViewById(R.id.tablaPelicula);
        tablaTituloPelicula = (TableRow) inflate.findViewById(R.id.tablaTituloPelicula);
        tablaCalificacionesPelicula = (TableRow) inflate.findViewById(R.id.tablaCalificacionesPelicula);
        contenedorDeLayoutsPeliculas.addView(inflate);
    }
    public void onBackPressed (){
        finish();
    }
    //Dependiendo de la puntuación, habrá unas estrellas coloreadas
    private void pintarPuntuacion(int index){
        if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(index).PUNTUACION_PELICULA == 1){
            estrellaPelicula1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
        }else if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(index).PUNTUACION_PELICULA == 2){
            estrellaPelicula1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
        }else if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(index).PUNTUACION_PELICULA == 3){
            estrellaPelicula1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
        }else if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(index).PUNTUACION_PELICULA == 4){
            estrellaPelicula1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula4.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
        }else if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(index).PUNTUACION_PELICULA == 5){
            estrellaPelicula1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula4.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
            estrellaPelicula5.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaa));
        }
    }
}