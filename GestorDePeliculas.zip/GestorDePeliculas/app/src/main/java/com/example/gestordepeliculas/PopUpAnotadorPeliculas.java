package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PopUpAnotadorPeliculas extends AppCompatActivity {

    EditText peliAnotada;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up_anotador_peliculas);

        peliAnotada = (EditText) findViewById(R.id.peliAnotada);

        //Haremos uso de esta clase para adaptar el tamaño de la ventana emergente
        DisplayMetrics medidasVentana = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(medidasVentana);

        int ancho = medidasVentana.widthPixels;
        int alto = medidasVentana.heightPixels;
        //Redimensiono el pop-up
        getWindow().setLayout((int)(ancho * 0.90),(int)(alto * 0.10));

        //Añado la película anotada, si no se escribió nada no se añade
        peliAnotada.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(!peliAnotada.getText().toString().equals("")){
                    Intent intent = new Intent(getApplication(), CuentaActivity.class);
                    @SuppressLint("UseCompatLoadingForDrawables") Pelicula  filmAnotado = new Pelicula(peliAnotada.getText().toString(),getResources().getDrawable(R.drawable.fotopordefecto),0);
                    MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.add(filmAnotado);
                    Toast.makeText(getApplicationContext(),R.string.yeFilmAdded, Toast.LENGTH_LONG).show();
                    MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).generoMasVisto(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).recogerDatosGenero());
                    MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).generoMenosVisto(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).recogerDatosGenero());
                    startActivity(intent);
                    finish();
                    return true;

                }else{
                    Toast.makeText(getApplicationContext(), R.string.noFilmAdded, Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });
    }
    public void onBackPressed (){
        finish();
    }

}