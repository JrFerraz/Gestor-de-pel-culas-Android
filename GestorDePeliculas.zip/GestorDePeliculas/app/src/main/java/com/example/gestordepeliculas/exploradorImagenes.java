package com.example.gestordepeliculas;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class exploradorImagenes extends AppCompatActivity {
    int SELECT_PHOTO = 1;
    Uri uri;
    ImageView mImageView;
    Button mChooseBtn;
    Button confirmarImagen;
    Image x;

    private static final  int PERMISSION_CODE = 1001;
    public static final int PICK_IMAGE = 1;
    boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explorador_imagenes);

        mChooseBtn = findViewById(R.id.choose_image_btn);
        mImageView = findViewById(R.id.image_view);
        confirmarImagen = findViewById(R.id.confirmarImagen);

        //Aceptar o rechazar permisos
        mChooseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        flag = true;
                        requestPermissions(permissions, PERMISSION_CODE);
                    }else {
                        pickImageFromGallery();
                        flag = true;
                    }
                }
                else{
                    flag = true;
                    pickImageFromGallery();
                }

            }
        });
    }

    //Pasamos la imagen seleccionada a la activity de la película seleccionada
    public void confirmarImagen(View v){
        if(flag){
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Drawable x = Drawable.createFromStream(inputStream, uri.toString());
                peliSeleccionadaActivity.imagenPeli.setImageDrawable(x);
                finish();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }else{
            finish();
            Toast.makeText(this,R.string.noImageChoosen,Toast.LENGTH_LONG).show();
        }
    }

    //Seleccionamos una imagen
    private void pickImageFromGallery(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    //Si tenemos permisos ejecutar funcion anterior, si no, acceso denegado
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case PERMISSION_CODE:{
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    pickImageFromGallery();
                }
                else {
                    Toast.makeText(this,"Permission Denied", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    //cogemos la path de la imagen en cuestion y la añadimos a un uri
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE){
            uri = data.getData();
            mImageView.setImageURI(data.getData());
        }
    }
}