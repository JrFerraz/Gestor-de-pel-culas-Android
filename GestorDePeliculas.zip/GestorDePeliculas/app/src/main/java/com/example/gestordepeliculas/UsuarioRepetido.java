package com.example.gestordepeliculas;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class UsuarioRepetido extends DialogFragment {

    //Fragment que se invoca si el usuario está repetido
    public Dialog onCreateDialog(Bundle savedInstance) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.Atencion).setIcon(R.drawable.darkalerticon)
                .setMessage(R.string.repetido)
                .setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        return builder.create();
    }
}
