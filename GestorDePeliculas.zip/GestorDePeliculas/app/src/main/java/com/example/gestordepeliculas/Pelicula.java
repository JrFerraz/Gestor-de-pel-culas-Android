package com.example.gestordepeliculas;

import android.graphics.drawable.Drawable;

public class Pelicula {

    //Características de una película
    String NOMBRE_PELICULA;
    boolean PELICULA_VISTA;
    Drawable fotoPelicula;
    int numVisualizaciones;
    String DESCRIPCION_PELICULA;
    int PUNTUACION_PELICULA;
    String [] generosPelicula = {"Sin Género","Acción","Aventuras","Ciencia Ficción","Romántica","Animación","Comedia","Thriller"};
    String GENERO_PELICULA;

    public Pelicula (String NP, Drawable fotoDefault, int puntuacion){
        this.NOMBRE_PELICULA = NP;
        this.PELICULA_VISTA = false;
        this.DESCRIPCION_PELICULA = "Aquí va la descripción de la película...";
        this.fotoPelicula = fotoDefault;
        this.numVisualizaciones = 0;
        this.PUNTUACION_PELICULA = puntuacion;
        this.GENERO_PELICULA = generosPelicula[0];
    }

    public void setPELICULA_VISTA(boolean PELICULA_VISTA) {
        this.PELICULA_VISTA = PELICULA_VISTA;
    }
}
