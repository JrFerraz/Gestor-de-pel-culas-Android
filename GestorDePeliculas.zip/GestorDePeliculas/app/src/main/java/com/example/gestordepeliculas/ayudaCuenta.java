package com.example.gestordepeliculas;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class ayudaCuenta extends DialogFragment {

    //DialogFragment de ayuda para la cuenta
    public Dialog onCreateDialog(Bundle savedInstance) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.ayudaEnCuenta).setIcon(R.drawable.ayuda)
                .setMessage(R.string.HELP)
                .setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        return builder.create();
    }
}
