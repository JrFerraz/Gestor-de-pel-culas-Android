package com.example.gestordepeliculas;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;

public class Usuario {

    //Características de un usuario
    int ID_USUARIO = 0;
    String NOM_USUARIO;
    String APELLIDOS_USUARIO;
    String PASS_USUARIO;
    boolean masculino;
    Drawable fondo;
    ArrayList<Pelicula> PELIS_USUARIO = new ArrayList<>();
    String peliMejorValorada;
    String peliPeorValorada;
    String generoMasVisto;
    String generoMenosVisto;

    public Usuario (String nombre, String apellidos, String pass, boolean sex, Drawable f){

        this.ID_USUARIO = MainActivity.users.size();
        this.NOM_USUARIO = nombre;
        this.APELLIDOS_USUARIO = apellidos;
        this.PASS_USUARIO = pass;
        this.masculino = sex;
        this.fondo = f;
    }

    //Recorre el array de pelis del usuario elegido y saca la que mayor puntuación tenga
    public void peliMejorValorada() {
        int aux = 0;
        int ind = 0;
        for (int i = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size()-1; i >= 0; i--) {
            if (MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PUNTUACION_PELICULA > aux) {
                ind = i;
                aux = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PUNTUACION_PELICULA;
            }
        }
        peliMejorValorada = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(ind).NOMBRE_PELICULA;
    }
    //Funcion contraria a peliMejorValorada
    public void peliPeorValorada(){
        int aux = 6;
        int ind = 0;
        for (int i = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size()-1; i >= 0 ;i--){
            if (MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PUNTUACION_PELICULA < aux){
                ind = i;
                aux = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PUNTUACION_PELICULA;
            }
        }
        peliPeorValorada = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(ind).NOMBRE_PELICULA;
    }
    String [] generosPelicula = {"Sin Género","Acción","Aventuras","Ciencia Ficción","Romántica","Animación","Comedia","Thriller"};

    //Recoge cuantas peliculas hay de cada género
    public int[] recogerDatosGenero(){
        int [] generos = {0,0,0,0,0,0,0,0};
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size();i++){
            for (int j = 0; j < generosPelicula.length;j++){
                if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).GENERO_PELICULA.equals(generosPelicula[j])){
                    generos[j] += 1;
                }
            }
        }
        int genMasVisto = 0;
        for (int x = 0; x < generos.length; x++){
            if(generos[x] > genMasVisto){
                genMasVisto = generos[x];
            }
        }
        return generos;
    }
    //Basada en la anterior función, recorre el array generado anteriormente para ver en que posicion tiene el número mas alto
    public void generoMasVisto(int[] generos){
        int genMasVisto = 0;
        int indice = 0;
        for (int x = 0; x < generos.length; x++){
            if(generos[x] > genMasVisto){
                genMasVisto = generos[x];
                indice = x;
            }
        }
        generoMasVisto = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(0).generosPelicula[indice];
    }
    //Función contraria a generoMasVisto
    public void generoMenosVisto(int[] generos){
        int genMenosVisto = 10000;
        int indice = 0;
        for (int x = generos.length-1; x >= 0; x--){
            if(generos[x] < genMenosVisto){
                genMenosVisto = generos[x];
                indice = x;
            }
        }
        generoMenosVisto = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(0).generosPelicula[indice];
    }
}
