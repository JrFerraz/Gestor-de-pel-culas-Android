package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class peliSeleccionadaActivity extends AppCompatActivity {

    static int indexPelicula = 0;
    Bundle pasarPeli;

    TextView DescripcionEscritaTV;
    TextView PeliculaTV;
    TextView conteoViewsTV;
    ImageButton imageButton1;
    ImageButton imageButton2;
    ImageButton imageButton3;
    ImageButton imageButton4;
    ImageButton imageButton5;
    public static ImageView imagenPeli;
    Switch SwitchVista;
    Spinner generoSpinner;

    boolean estr1 =false;
    boolean estr2 =false;
    boolean estr3 =false;
    boolean estr4 =false;
    boolean estr5 =false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peli_seleccionada);

        pasarPeli = getIntent().getExtras();
        indexPelicula = pasarPeli.getInt("IndexPeli");

        PeliculaTV = (TextView) findViewById(R.id.PeliculaTV);
        DescripcionEscritaTV = (TextView) findViewById(R.id.DescripcionEscritaTV);
        conteoViewsTV = (TextView) findViewById(R.id.cuentoViewsTV);
        imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
        imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
        imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
        imageButton4 = (ImageButton) findViewById(R.id.imageButton4);
        imageButton5 = (ImageButton) findViewById(R.id.imageButton5);
        imagenPeli = (ImageView) findViewById(R.id.imagenPeli);
        SwitchVista = (Switch) findViewById(R.id.SwitchVista);
        generoSpinner = (Spinner) findViewById(R.id.generoSpinner);
        generoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //nomFondo = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //nomFondo = parent.getItemAtPosition(0).toString();
            }
        });

        iniciarActivity();


    }
    //Adaptamos la activity a la peli seleccionada
    private void iniciarActivity(){
        PeliculaTV.setText(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).NOMBRE_PELICULA);
        DescripcionEscritaTV.setText(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).DESCRIPCION_PELICULA);
        conteoViewsTV.setText(Integer.toString(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).numVisualizaciones));
        generoSpinner.setSelection(recogerGenero());
        SwitchVista.setChecked(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).PELICULA_VISTA);
        activarEstrellas(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).PUNTUACION_PELICULA);
        imagenPeli.setImageDrawable(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).fotoPelicula);
    }
    //Validamos los cambios
    public void saveFilm(View v){

        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).DESCRIPCION_PELICULA = DescripcionEscritaTV.getText().toString();
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).GENERO_PELICULA = MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).generosPelicula[generoSpinner.getSelectedItemPosition()];
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).PUNTUACION_PELICULA = sacarPuntuacion();
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).numVisualizaciones = Integer.parseInt(conteoViewsTV.getText().toString());
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).fotoPelicula = imagenPeli.getDrawable();
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).PELICULA_VISTA = SwitchVista.isChecked();
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).peliMejorValorada();
        MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).peliPeorValorada();
        startActivity(new Intent(peliSeleccionadaActivity.this, CuentaActivity.class));
        finish();
    }
    //Pilla el género de la película
    private int recogerGenero(){
        for (int i=0;i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).generosPelicula.length;i++){
            if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).GENERO_PELICULA.equals(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(indexPelicula).generosPelicula[i])){
                return i;
            }
        }
        return 0;
    }

    //Obtiene el entero a partir de los valores de las estrellas
    public int sacarPuntuacion(){

        if(estr1 && estr2 && estr3 && estr4 && estr5){
            return 5;
        }else if(estr1 && estr2 && estr3 && estr4){
            return 4;
        }else if(estr1 && estr2 && estr3){
            return 3;
        }else if(estr1 && estr2){
            return 2;
        }else if(estr1){
            return 1;
        }else{
            return 0;
        }

    }
    //De aquí en adelante es el código para que las estrellas hagan lo que quiero
    private void activarEstrellas(int puntuacion){
        switch (puntuacion) {
            case 5:
                estrella5();
                break;
            case 4:
                estrella4();
                break;
            case 3:
                estrella3();
                break;
            case 2:
                estrella2();
                break;
            case 1:
                estrella1();
                break;
        }
    }
    public void llamarCambiadorDeFotos(View v){
        startActivity(new Intent(peliSeleccionadaActivity.this,exploradorImagenes.class));
    }
    @Override
    public void onBackPressed (){
        finish();
    }
    //Añade 1 visualización menos a la pelicula
    public void minusViews(View v){
        if(!conteoViewsTV.getText().toString().equals("0")){
            conteoViewsTV.setText(Integer.parseInt(conteoViewsTV.getText().toString())-1+"");
        }
    }
    //Lo contrario de minusViews
    public void plusViews(View v){
        conteoViewsTV.setText(Integer.parseInt(conteoViewsTV.getText().toString())+1+"");
    }
    //Codigo para que funcionen las estrellas
    private void estrella1 (){
        if(!estr1){
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            estr1 = true;
        }else {
            estr1 = false;
            estr2 = false;
            estr3 = false;
            estr4 = false;
            estr5 = false;
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
        }
    }
    private void estrella2 (){
        if(!estr2){
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            estr1 = true;
            estr2 = true;
        }else {
            estr2 = false;
            estr3 = false;
            estr4 = false;
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
        }
    }
    private void estrella3 (){
        if(!estr3){
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            estr1 = true;
            estr2 = true;
            estr3 = true;
        }else {
            estr3 = false;
            estr4 = false;
            estr5 = false;
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
        }
    }
    private void estrella4 (){
        if(!estr4){
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            estr1 = true;
            estr2 = true;
            estr3 = true;
            estr4 = true;
        }else {
            estr4 = false;
            estr5 = false;
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
        }
    }
    private void estrella5 (){
        if(!estr4){
            imageButton1.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton2.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton3.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton4.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellarellenaapeque));
            estr1 = true;
            estr2 = true;
            estr3 = true;
            estr4 = true;
            estr5 = true;
        }else {
            estr5 = false;
            imageButton5.setImageDrawable(getResources().getDrawable(R.drawable.estrellavaciapeque));
        }
    }
    public void estrellaClick1(View v){
        estrella1();
    }
    public void estrellaClick2(View v){
        estrella2();
    }
    public void estrellaClick3(View v){
        estrella3();
    }
    public void estrellaClick4(View v){
        estrella4();
    }
    public void estrellaClick5(View v){
        estrella5();
    }
}