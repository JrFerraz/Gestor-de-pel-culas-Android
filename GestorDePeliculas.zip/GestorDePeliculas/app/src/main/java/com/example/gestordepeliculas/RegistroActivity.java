package com.example.gestordepeliculas;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class RegistroActivity extends AppCompatActivity {

    EditText nameRegET;
    EditText ApellidoRegET;
    EditText ContraseñaRegET;
    Switch sexoSwitch;
    Spinner fondoSpinner;
    String nomFondo;


    //con las dependencias instaladas, el gif es otro tipo de vista más, la inicializamos
    pl.droidsonroids.gif.GifImageView GIF;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro);

        nameRegET = (EditText) findViewById(R.id.nameRegET);
        ApellidoRegET = (EditText) findViewById(R.id.ApellidoRegET);
        ContraseñaRegET = (EditText) findViewById(R.id.ContraseñaRegET);
        GIF = (pl.droidsonroids.gif.GifImageView) findViewById(R.id.GIF);
        sexoSwitch = (Switch) findViewById(R.id.sexoSwitch);
        fondoSpinner = (Spinner) findViewById(R.id.fondoSpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.fotosPerfil, R.layout.support_simple_spinner_dropdown_item);
        fondoSpinner.setAdapter(adapter);

        fondoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                nomFondo = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                nomFondo = parent.getItemAtPosition(0).toString();
            }
        });
    }
    @SuppressLint("UseCompatLoadingForDrawables")
    private Drawable seleccionarFondo (String fotoPerfil){
        Drawable x = getResources().getDrawable(R.drawable.batimagen);
        switch (fotoPerfil) {
            case "Batman":
                x = getResources().getDrawable(R.drawable.batimagen);
                break;
            case "Rocky":
                x = getResources().getDrawable(R.drawable.rocky);
                break;
            case "007":
                x = getResources().getDrawable(R.drawable.cerosietes);
                break;
            case "El Padrino":
                x = getResources().getDrawable(R.drawable.erpadrino);
                break;
            case "John Wick":
                x = getResources().getDrawable(R.drawable.jonaselpipas);
                break;
            case "Los Vengadores":
                x = getResources().getDrawable(R.drawable.vengativos);
                break;
        }
        return x;
    }
    public void cambioSexo (View v){

    }
    //Evita que se repitan usuarios
    private boolean HayRepetido(){
        for (int i = 0; i < MainActivity.users.size(); i++){
            if(nameRegET.getText().toString().equals(MainActivity.users.get(i).NOM_USUARIO) && ContraseñaRegET.getText().toString().equals(MainActivity.users.get(i).PASS_USUARIO)){
                UsuarioRepetido us = new UsuarioRepetido();
                FragmentManager fm = this.getSupportFragmentManager();
                us.show(fm,"errorRegister");
                return true;
            }
        }
        return false;
    }
    //Llama al gif correspondiente segun el contexto
    public void invocarGIF(){
        CountDownTimer countDownTimer = new CountDownTimer(2000, 1000) {
            public void onTick(long millisUntilFinished) {
                mostrarGIF(true);
            }

            public void onFinish() {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        }.start();
    }
    public void RegisterAction (View v) throws InterruptedException {
        CrearUsuario();
    }
    //Si no hay repetido y los campos no estan vacíos, se crea el usuario
    public void CrearUsuario () throws InterruptedException {
        if(!comprobarVacios() && !HayRepetido()){
            Usuario user = new Usuario(nameRegET.getText().toString(),ApellidoRegET.getText().toString(),ContraseñaRegET.getText().toString(),sexoSwitch.isChecked(),seleccionarFondo(nomFondo));
            MainActivity.users.add(user);
            Toast.makeText(this, R.string.goodRegister,Toast.LENGTH_LONG).show();
            invocarGIF();
            //mostrarGIF(true);
            //Intent intent = new Intent(this, MainActivity.class);
            //startActivity(intent);
            //finish();
        }else{
            mostrarGIF(false);
        }
    }
    //Se mostrará el correcto o el incorrecto dependiendo del contexto
    public void mostrarGIF(boolean x){
        if(x){
            GIF.setImageResource(R.drawable.correcto);
        }else{
            GIF.setImageResource(R.drawable.error);
        }
    }
    //comprueba los campos
    private boolean comprobarVacios(){
        if(nameRegET.getText().toString().equals("") && ApellidoRegET.getText().toString().equals("") && ContraseñaRegET.getText().toString().equals("")){
            Toast.makeText(this, R.string.nullRegister,Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }
    //Mostrar Ocultar Menu
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.registrobar, menu);
        return true;
    }

    //Controles del menu
    public boolean onOptionsItemSelected(MenuItem item){

        int selector = item.getItemId();
        if(selector == R.id.itemAyuda){
            Toast.makeText(this, R.string.ayudaPass, Toast.LENGTH_LONG).show();
        }else if(selector == R.id.itemSalir){
            cancelarRegistro();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed (){
         cancelarRegistro();
    }
    //llama al aviso de SalirRegistro
    public void cancelarRegistro (){
        //Mostramos el dialogo
        SalirRegistro salir = new SalirRegistro();
        FragmentManager fm = this.getSupportFragmentManager();
        salir.setCancelable(false);
        salir.show(fm,"salir");
    }
}
