package com.example.gestordepeliculas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ActualizarVistas extends AppCompatActivity {

    LinearLayout actualizarVistasLinearLayout;
    CheckBox x;
    Button updateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar_vistas);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
        actualizarVistasLinearLayout = (LinearLayout) findViewById(R.id.actualizarVistasLinearLayout);

        //Se genera un numero de checkBox equivalente a la cantidad de peliculas, cada checkbox lleva el nombre de una pelicula
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size(); i++){
            CheckBox x = new CheckBox(this);
            x.setText(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).NOMBRE_PELICULA);
            x.setChecked(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).PELICULA_VISTA);
            x.setLayoutParams(params);
            actualizarVistasLinearLayout.addView(x);
        }
    }
    //Si presionas la tecla Back finaliza la activity
    @Override
    public void onBackPressed (){
        finish();
    }

    //Valida lo modificado en la activity, evalua si cada CheckBox esta Checked o no, si lo esta, la peli se marca como vista, si no, lo contrario
    public void pillar (View v){
        for (int j = 0;j < actualizarVistasLinearLayout.getChildCount();j++){
            if(actualizarVistasLinearLayout.getChildAt(j) instanceof CheckBox){
                    actualizarPeliculas(((CheckBox) actualizarVistasLinearLayout.getChildAt(j)), ((CheckBox) actualizarVistasLinearLayout.getChildAt(j)).isChecked());
                    Toast.makeText(this,R.string.regisUpdated,Toast.LENGTH_LONG).show();
            }
        }
    }
    //combinada con la anterior función forman la validacion total de peliculas, se les pasa el nomPelicula y si el checkBox esta checked o no,
    //si encuentra la peli deseada rompe
    private void actualizarPeliculas(CheckBox x, boolean y){
        for (int i = 0; i < MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.size(); i++){
            if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).NOMBRE_PELICULA.equals(x.getText().toString()) && y){
                MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).setPELICULA_VISTA(true);
                break;
            }
            if(MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).NOMBRE_PELICULA.equals(x.getText().toString()) && !y){
                MainActivity.users.get(CuentaActivity.ID_USUARIO_ACTUAL).PELIS_USUARIO.get(i).setPELICULA_VISTA(false);
                break;
            }

        }
    }
}